package com.avenro.launcher.install

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object Permissions {
    /** Разрешено ли лаунчеру устанавливать APK ("Установка неизвестных приложений") */
    fun canInstallApks(ctx: Context) = ctx.packageManager.canRequestPackageInstalls()

    /** Открывает системный экран, где пользователь включает разрешение для лаунчера */
    fun openInstallSettings(ctx: Context) {
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
    }
}
