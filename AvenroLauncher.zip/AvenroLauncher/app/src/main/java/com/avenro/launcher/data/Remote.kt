package com.avenro.launcher.data

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.Authenticator
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.Route
import org.json.JSONObject
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.IOException
import java.time.OffsetDateTime
import java.util.concurrent.TimeUnit

// ---------- Сессия (токены) ----------
class SessionStore(private val p: SharedPreferences) {
    val accessToken: String? get() = p.getString("at", null)
    val refreshToken: String? get() = p.getString("rt", null)
    val loggedIn = MutableStateFlow(refreshToken != null)
    fun save(access: String, refresh: String) {
        p.edit().putString("at", access).putString("rt", refresh).apply(); loggedIn.value = true
    }
    fun clear() { p.edit().clear().apply(); loggedIn.value = false }
}

// ---------- DTO ----------
data class SignInBody(val email: String, val password: String)
data class SignUpBody(val email: String, val password: String, val data: Map<String, String>)
data class AuthResponse(val access_token: String?, val refresh_token: String?)
data class ProfileDto(val public_id: Long, val nickname: String, val donate_coins: Int, val avatar_url: String?)
data class ServerDto(val id: Int, val name: String, val online: Int, val status: String, val image_url: String?)
data class NewsDto(val title: String, val summary: String, val url: String?, val published_at: String)
data class CharacterDto(
    val id: Long, val slot: Int, val first_name: String, val last_name: String, val gender: String,
    val level: Int, val skin_id: Int, val last_played: String?, val image_url: String?
)
data class CreateCharBody(val p_server: Int, val p_first: String, val p_last: String, val p_gender: String)

// ---------- API (Supabase REST + Auth) ----------
interface SupabaseApi {
    @POST("auth/v1/signup") suspend fun signUp(@Body b: SignUpBody): AuthResponse
    @POST("auth/v1/token?grant_type=password") suspend fun signIn(@Body b: SignInBody): AuthResponse
    @GET("rest/v1/profiles?select=public_id,nickname,donate_coins,avatar_url&limit=1") suspend fun profile(): List<ProfileDto>
    @GET("rest/v1/servers?select=*&status=eq.online&order=id") suspend fun servers(): List<ServerDto>
    @GET("rest/v1/news?select=*&order=published_at.desc&limit=5") suspend fun news(): List<NewsDto>
    @GET("rest/v1/characters?select=*&order=slot") suspend fun characters(@Query("server_id") serverFilter: String): List<CharacterDto>
    @POST("rest/v1/rpc/create_character") suspend fun createCharacter(@Body b: CreateCharBody): CharacterDto
}

private class TokenAuthenticator(private val session: SessionStore) : Authenticator {
    override fun authenticate(route: Route?, response: Response): Request? {
        val sent = response.request.header("Authorization") ?: return null
        if (generateSequence(response) { it.priorResponse }.count() > 2) return null
        synchronized(this) {
            val current = session.accessToken
            if (current != null && sent != "Bearer $current")
                return response.request.newBuilder().header("Authorization", "Bearer $current").build()
            val rt = session.refreshToken ?: return null
            val body = JSONObject().put("refresh_token", rt).toString().toRequestBody("application/json".toMediaType())
            val req = Request.Builder()
                .url("${AppConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
                .header("apikey", AppConfig.SUPABASE_KEY).post(body).build()
            try {
                OkHttpClient().newCall(req).execute().use { r ->
                    if (!r.isSuccessful) { if (r.code in 400..499) session.clear(); return null }
                    val j = JSONObject(r.body!!.string())
                    session.save(j.getString("access_token"), j.getString("refresh_token"))
                }
            } catch (e: IOException) { return null }
            return response.request.newBuilder().header("Authorization", "Bearer ${session.accessToken}").build()
        }
    }
}

fun buildApi(session: SessionStore): SupabaseApi {
    val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS)
        .addInterceptor(Interceptor { chain ->
            val b = chain.request().newBuilder().header("apikey", AppConfig.SUPABASE_KEY)
            val token = session.accessToken
            if (token != null && !chain.request().url.encodedPath.startsWith("/auth/")) b.header("Authorization", "Bearer $token")
            chain.proceed(b.build())
        })
        .authenticator(TokenAuthenticator(session))
        .build()
    return Retrofit.Builder().baseUrl(AppConfig.SUPABASE_URL + "/").client(client)
        .addConverterFactory(GsonConverterFactory.create()).build().create(SupabaseApi::class.java)
}

// ---------- Репозитории ----------
class AuthRepository(private val api: SupabaseApi, private val session: SessionStore) {
    suspend fun signIn(email: String, password: String) {
        val r = api.signIn(SignInBody(email, password))
        session.save(r.access_token ?: error("Не удалось войти"), r.refresh_token ?: error("Не удалось войти"))
    }
    /** true — сессия создана; false — нужно подтвердить почту. */
    suspend fun signUp(email: String, password: String, nickname: String): Boolean {
        val r = api.signUp(SignUpBody(email, password, mapOf("nickname" to nickname)))
        val a = r.access_token; val t = r.refresh_token
        if (a == null || t == null) return false
        session.save(a, t); return true
    }
    fun signOut() = session.clear()
}

class RemoteAccountRepository(private val api: SupabaseApi) : AccountRepository {
    override suspend fun account(): Account {
        val p = api.profile().firstOrNull() ?: error("Профиль не найден")
        return Account(p.public_id.toString(), p.nickname, p.donate_coins, p.avatar_url)
    }
}
class RemoteServerRepository(private val api: SupabaseApi) : ServerRepository {
    override suspend fun servers() = api.servers().map {
        Server(it.id, it.name, it.online, when (it.status) {
            "online" -> ServerStatus.ONLINE; "maintenance" -> ServerStatus.MAINTENANCE; else -> ServerStatus.OFFLINE
        }, it.image_url)
    }.filter { it.status == ServerStatus.ONLINE }
}
class RemoteNewsRepository(private val api: SupabaseApi) : NewsRepository {
    override suspend fun news() = api.news().map {
        val d = it.published_at.split("-")
        NewsItem(it.title, it.summary, if (d.size == 3) "${d[2]}.${d[1]}.${d[0]}" else it.published_at, it.url)
    }
}
class RemoteCharacterRepository(private val api: SupabaseApi) : CharacterRepository {
    private fun CharacterDto.toModel() = Character(
        id.toInt(), first_name, last_name, level, skin_id,
        runCatching { OffsetDateTime.parse(last_played!!).toInstant().toEpochMilli() }.getOrDefault(0L), image_url
    )
    override suspend fun slots(serverId: Int): List<Character?> {
        val rows = api.characters("eq.$serverId")
        return List(AppConfig.MAX_CHARACTERS) { i -> rows.firstOrNull { it.slot == i }?.toModel() }
    }
    override suspend fun create(serverId: Int, firstName: String, lastName: String, gender: String) =
        api.createCharacter(CreateCharBody(serverId, firstName, lastName, gender)).toModel()
}

// ---------- Человекочитаемые ошибки ----------
fun Throwable.toUserMessage(): String {
    if (this is HttpException) {
        val raw = runCatching { response()?.errorBody()?.string() }.getOrNull().orEmpty()
        val j = runCatching { JSONObject(raw) }.getOrNull()
        val msg = listOf("message", "msg", "error_description").map { j?.optString(it).orEmpty() }.firstOrNull { it.isNotBlank() } ?: ""
        return when {
            msg.contains("Invalid login credentials", true) -> "Неверная почта или пароль"
            msg.contains("already registered", true) -> "Эта почта уже зарегистрирована"
            msg.contains("at least", true) -> "Пароль: минимум 6 символов"
            msg.contains("rate limit", true) -> "Слишком много попыток, подождите"
            msg.contains("not confirmed", true) -> "Подтвердите почту"
            msg.contains("valid email", true) || msg.contains("validate email", true) -> "Некорректная почта"
            msg.isNotBlank() -> msg
            code() == 401 -> "Сессия истекла, войдите снова"
            else -> "Ошибка сервера (${code()})"
        }
    }
    if (this is IOException) return "Нет соединения с интернетом"
    return message ?: "Неизвестная ошибка"
}
