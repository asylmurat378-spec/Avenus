package com.avenro.launcher.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun AuthScreen(vm: LauncherViewModel) {
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf("") }
    val busy by vm.authBusy.collectAsStateWithLifecycle()
    val err by vm.authError.collectAsStateWithLifecycle()
    val valid = email.contains("@") && pw.length >= 6 && (!register || nick.trim().length >= 3)
    val colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Gray,
        focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Purple,
        focusedLabelColor = Purple, unfocusedLabelColor = Gray)
    ScreenBg {
        Row(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("AVENRO", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Text("ROLEPLAY", color = Purple, fontSize = 20.sp, fontWeight = FontWeight.Black,
                    fontStyle = FontStyle.Italic, letterSpacing = 6.sp)
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (register) "РЕГИСТРАЦИЯ" else "ВХОД", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                if (register) OutlinedTextField(nick, { nick = it.take(20) }, Modifier.fillMaxWidth(),
                    label = { Text("Никнейм") }, singleLine = true, colors = colors)
                OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Почта") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), colors = colors)
                OutlinedTextField(pw, { pw = it }, Modifier.fillMaxWidth(), label = { Text("Пароль (от 6 символов)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), colors = colors)
                err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }
                PrimaryButton(if (busy) "Подождите…" else if (register) "Создать аккаунт" else "Войти",
                    modifier = Modifier.fillMaxWidth(), enabled = valid && !busy) {
                    if (register) vm.signUp(email, pw, nick) else vm.signIn(email, pw)
                }
                TextButton({ register = !register; vm.authError.value = null }) {
                    Text(if (register) "Уже есть аккаунт? Войти" else "Нет аккаунта? Регистрация", color = Gray)
                }
            }
        }
    }
}
