package com.avenro.launcher.install

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build

/** Получает от системы результат установки APK (PackageInstaller). */
class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm: Intent? =
                    if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                    else @Suppress("DEPRECATION") intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) GameInstaller.onNeedsConfirm(confirm)
                else GameInstaller.onInstallFailed(status, "нет окна подтверждения")
            }
            PackageInstaller.STATUS_SUCCESS -> GameInstaller.onInstalled(context)
            else -> GameInstaller.onInstallFailed(status, intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE))
        }
    }
    companion object { const val ACTION = "com.avenro.launcher.INSTALL_RESULT" }
}
