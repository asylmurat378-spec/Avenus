package com.avenro.launcher.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avenro.launcher.install.*

/** Окно прогресса загрузки/установки поверх любого экрана. */
@Composable
fun InstallOverlay(onRetry: (Context) -> Unit) {
    val state by GameInstaller.state.collectAsStateWithLifecycle()
    val s = state
    val ctx = LocalContext.current
    if (s is InstallState.Idle || s is InstallState.Done) return

    if (s is InstallState.NeedsConfirm) {
        // Открываем системное окно «Установить приложение?» (из видимого Activity это разрешено)
        LaunchedEffect(s.intent) {
            runCatching { ctx.startActivity(Intent(s.intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .78f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        Alignment.Center
    ) {
        Column(
            Modifier.width(480.dp).clip(RoundedCornerShape(20.dp)).background(Graphite).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (s) {
                is InstallState.Working -> {
                    Text(s.stage.title.uppercase(), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(s.label, color = Gray, fontSize = 14.sp)
                    if (s.total > 0) {
                        LinearProgressIndicator(
                            progress = { (s.done.toFloat() / s.total).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = Purple, trackColor = Color.White.copy(alpha = .1f)
                        )
                        val pct = (s.done * 100 / s.total).coerceIn(0, 100)
                        val speed = if (s.stage == Stage.DOWNLOAD && s.speed > 0) "  •  ${fmtBytes(s.speed)}/с" else ""
                        Text("$pct%  •  ${fmtBytes(s.done)} / ${fmtBytes(s.total)}$speed", color = Color.White, fontSize = 14.sp)
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = Purple, trackColor = Color.White.copy(alpha = .1f)
                        )
                    }
                    if (s.stage != Stage.INSTALL) {
                        TextButton(onClick = { GameInstaller.cancel() }, modifier = Modifier.align(Alignment.End)) {
                            Text("Отмена", color = Gray)
                        }
                    }
                }
                is InstallState.NeedsConfirm -> {
                    Text("ПОДТВЕРДИТЕ УСТАНОВКУ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Система спросит, можно ли установить игру. Нажмите «Установить».", color = Gray, fontSize = 14.sp)
                    PrimaryButton("Открыть окно установки", null, Modifier.fillMaxWidth()) {
                        runCatching { ctx.startActivity(Intent(s.intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }
                }
                is InstallState.Failed -> {
                    Text("ОШИБКА", color = Color(0xFFFF5C5C), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(s.message, color = Color.White, fontSize = 15.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        PrimaryButton("Повторить", null, Modifier.weight(1f)) { onRetry(ctx) }
                        TextButton(onClick = { GameInstaller.reset() }) { Text("Закрыть", color = Gray) }
                    }
                }
                else -> {}
            }
        }
    }
}
