package com.avenro.launcher.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.delay
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

// ---------- Config (меняйте ссылки здесь, UI трогать не нужно) ----------
object AppConfig {
    const val API_BASE_URL = "https://api.avenro.example/"
    const val DISCORD_URL = "https://discord.gg/avenro"
    const val TELEGRAM_URL = "https://t.me/avenro"
    const val DONATE_URL = "https://avenro.example/donate"
    const val MAX_CHARACTERS = 3
    const val FORUM_ENABLED = false
}

// ---------- Models ----------
data class Account(val id: String, val nickname: String, val donateCoins: Int, val avatarUrl: String?)
enum class ServerStatus { ONLINE, OFFLINE, MAINTENANCE }
data class Server(val id: Int, val name: String, val online: Int, val status: ServerStatus, val imageUrl: String?)
data class Character(
    val id: Int, val firstName: String, val lastName: String, val level: Int,
    val skinId: Int, val lastPlayed: Long, val imageUrl: String?
)
data class NewsItem(val title: String, val summary: String, val date: String, val url: String?)
data class CreateCharacterRequest(val firstName: String, val lastName: String, val gender: String)

// ---------- API (Retrofit). Эндпоинты — пример, подгоните под ваш backend ----------
interface AvenroApi {
    @GET("account") suspend fun account(): Account
    @GET("servers") suspend fun servers(): List<Server>
    @GET("news") suspend fun news(): List<NewsItem>
    @GET("servers/{id}/characters") suspend fun characters(@Path("id") serverId: Int): List<Character>
    @POST("servers/{id}/characters") suspend fun createCharacter(@Path("id") serverId: Int, @Body r: CreateCharacterRequest): Character
}

// ---------- Repositories ----------
interface AccountRepository { suspend fun account(): Account }
interface ServerRepository { suspend fun servers(): List<Server> }
interface NewsRepository { suspend fun news(): List<NewsItem> }
interface CharacterRepository {
    /** Всегда список из MAX_CHARACTERS слотов; null = свободный слот. */
    suspend fun slots(serverId: Int): List<Character?>
    suspend fun create(serverId: Int, firstName: String, lastName: String, gender: String): Character
}

class ApiServerRepository(private val api: AvenroApi) : ServerRepository {
    override suspend fun servers() = api.servers().filter { it.status == ServerStatus.ONLINE }
}

// ---------- Demo-реализации (работают без backend) ----------
class DemoAccountRepository : AccountRepository {
    override suspend fun account(): Account { delay(400); return Account("748392", "Player", 12450, null) }
}
class DemoServerRepository : ServerRepository {
    override suspend fun servers(): List<Server> {
        delay(700)
        return listOf(
            Server(1, "Сервер #1", 3248, ServerStatus.ONLINE, null),
            Server(2, "Сервер #2", 1932, ServerStatus.ONLINE, null),
            Server(3, "Сервер #3", 1467, ServerStatus.ONLINE, null),
            Server(4, "Сервер #4", 0, ServerStatus.MAINTENANCE, null) // будет отфильтрован
        ).filter { it.status == ServerStatus.ONLINE }
    }
}
class DemoNewsRepository : NewsRepository {
    override suspend fun news(): List<NewsItem> {
        delay(300)
        return listOf(NewsItem("Добро пожаловать на AVENRO ROLEPLAY!",
            "Мы рады приветствовать вас на проекте. Создайте персонажа и начните свою историю.", "14.11.2025", null))
    }
}
class DemoCharacterRepository : CharacterRepository {
    private val store = mutableMapOf<Int, MutableList<Character?>>()
    private fun list(s: Int) = store.getOrPut(s) {
        if (s == 1) mutableListOf(
            Character(1, "Алекс", "Морган", 15, 1, System.currentTimeMillis(), null),
            Character(2, "Дэн", "Картер", 8, 2, 0, null),
            Character(3, "Марк", "Лоу", 12, 3, 0, null)
        ) else MutableList(AppConfig.MAX_CHARACTERS) { null }
    }
    override suspend fun slots(serverId: Int): List<Character?> { delay(400); return list(serverId).toList() }
    override suspend fun create(serverId: Int, firstName: String, lastName: String, gender: String): Character {
        delay(500)
        val l = list(serverId)
        val i = l.indexOfFirst { it == null }
        if (i < 0) error("Нет свободных слотов")
        return Character(serverId * 100 + i, firstName, lastName, 1, if (gender == "M") 1 else 2, 0, null).also { l[i] = it }
    }
}

// ---------- Launcher (точка интеграции с CRMP) ----------
sealed interface LaunchResult { object Success : LaunchResult; data class Failure(val reason: String) : LaunchResult }
interface GameLauncher {
    fun isClientInstalled(): Boolean
    fun verifyFiles(): Boolean
    /** Здесь передаём server/character совместимому CRMP-клиенту и запускаем его. */
    fun launch(context: Context, server: Server, character: Character): LaunchResult
}
/** Заглушка: реальная интеграция требует CRMP SDK/клиента, которых здесь нет. API не выдумываем. */
class UnconfiguredGameLauncher : GameLauncher {
    override fun isClientInstalled() = false
    override fun verifyFiles() = false
    override fun launch(context: Context, server: Server, character: Character): LaunchResult =
        LaunchResult.Failure("Игровой клиент CRMP не подключён. Реализуйте GameLauncher (см. README).")
}

// ---------- Updates ----------
interface UpdateChecker { suspend fun latestVersion(): String }
class DemoUpdateChecker : UpdateChecker { override suspend fun latestVersion(): String { delay(500); return "1.0.0" } }

// ---------- Settings ----------
class SettingsRepository(private val p: SharedPreferences) {
    var animations: Boolean
        get() = p.getBoolean("animations", true)
        set(v) = p.edit().putBoolean("animations", v).apply()
}

// ---------- DI ----------
object ServiceLocator {
    lateinit var settings: SettingsRepository
    val accounts: AccountRepository = DemoAccountRepository()
    val servers: ServerRepository = DemoServerRepository()
    val news: NewsRepository = DemoNewsRepository()
    val characters: CharacterRepository = DemoCharacterRepository()
    val launcher: GameLauncher = UnconfiguredGameLauncher()
    val updates: UpdateChecker = DemoUpdateChecker()
    fun init(c: Context) { settings = SettingsRepository(c.getSharedPreferences("avenro", Context.MODE_PRIVATE)) }
}
