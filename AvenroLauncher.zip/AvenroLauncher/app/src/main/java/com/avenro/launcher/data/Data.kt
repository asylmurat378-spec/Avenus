package com.avenro.launcher.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.delay

// ---------- Config (меняйте ссылки здесь, UI трогать не нужно) ----------
object AppConfig {
    const val SUPABASE_URL = "https://kxdbnrzevbxxfoesasgo.supabase.co"
    const val SUPABASE_KEY = "sb_publishable_JKNcYDlzL0tit0UHCDKp9A_iQKKroht" // публичный ключ, секретные сюда НЕ вставлять
    @Volatile var DISCORD_URL = "https://discord.gg/BcZySAXkzd"
    @Volatile var TELEGRAM_URL = "https://t.me/avenroroleplay"
    @Volatile var DONATE_URL = "https://avenro.example/donate"
    const val MAX_CHARACTERS = 3
    /** Package name установленного CRMP-клиента (например "com.xxx.client"). Пусто = клиент не настроен. */
    @Volatile var CLIENT_PACKAGE = ""
    /** Ссылка на скачивание клиента (открывается, если клиент не установлен). Можно оставить пустой. */
    @Volatile var CLIENT_DOWNLOAD_URL = ""
    @Volatile var FORUM_ENABLED = false
}

// ---------- Models ----------
data class Account(val id: String, val nickname: String, val donateCoins: Int, val avatarUrl: String?)
enum class ServerStatus { ONLINE, OFFLINE, MAINTENANCE }
data class Server(
    val id: Int, val name: String, val online: Int, val status: ServerStatus, val imageUrl: String?,
    val host: String? = null, val port: Int = 7777
)
data class Character(
    val id: Int, val firstName: String, val lastName: String, val level: Int,
    val skinId: Int, val lastPlayed: Long, val imageUrl: String?
)
data class NewsItem(val title: String, val summary: String, val date: String, val url: String?)
data class CreateCharacterRequest(val firstName: String, val lastName: String, val gender: String)

// ---------- Repositories ----------
interface AccountRepository { suspend fun account(): Account }
interface ServerRepository { suspend fun servers(): List<Server> }
interface NewsRepository { suspend fun news(): List<NewsItem> }
interface CharacterRepository {
    /** Всегда список из MAX_CHARACTERS слотов; null = свободный слот. */
    suspend fun slots(serverId: Int): List<Character?>
    suspend fun create(serverId: Int, firstName: String, lastName: String, gender: String): Character
}

// ---------- Demo-реализации (работают без backend) ----------
class DemoAccountRepository : AccountRepository {
    override suspend fun account(): Account { delay(400); return Account("748392", "Player", 12450, null) }
}
class DemoServerRepository : ServerRepository {
    override suspend fun servers(): List<Server> {
        delay(700)
        return listOf(
            Server(1, "Сервер #1", 3248, ServerStatus.ONLINE, null),
            Server(2, "Сервер #2", 1932, ServerStatus.ONLINE, null),
            Server(3, "Сервер #3", 1467, ServerStatus.ONLINE, null),
            Server(4, "Сервер #4", 0, ServerStatus.MAINTENANCE, null) // будет отфильтрован
        ).filter { it.status == ServerStatus.ONLINE }
    }
}
class DemoNewsRepository : NewsRepository {
    override suspend fun news(): List<NewsItem> {
        delay(300)
        return listOf(NewsItem("Добро пожаловать на AVENRO ROLEPLAY!",
            "Мы рады приветствовать вас на проекте. Создайте персонажа и начните свою историю.", "14.11.2025", null))
    }
}
class DemoCharacterRepository : CharacterRepository {
    private val store = mutableMapOf<Int, MutableList<Character?>>()
    private fun list(s: Int) = store.getOrPut(s) {
        if (s == 1) mutableListOf(
            Character(1, "Алекс", "Морган", 15, 1, System.currentTimeMillis(), null),
            Character(2, "Дэн", "Картер", 8, 2, 0, null),
            Character(3, "Марк", "Лоу", 12, 3, 0, null)
        ) else MutableList(AppConfig.MAX_CHARACTERS) { null }
    }
    override suspend fun slots(serverId: Int): List<Character?> { delay(400); return list(serverId).toList() }
    override suspend fun create(serverId: Int, firstName: String, lastName: String, gender: String): Character {
        delay(500)
        val l = list(serverId)
        val i = l.indexOfFirst { it == null }
        if (i < 0) error("Нет свободных слотов")
        return Character(serverId * 100 + i, firstName, lastName, 1, if (gender == "M") 1 else 2, 0, null).also { l[i] = it }
    }
}

// ---------- Launcher (точка интеграции с CRMP-клиентом) ----------
sealed interface LaunchResult { object Success : LaunchResult; data class Failure(val reason: String) : LaunchResult }
interface GameLauncher {
    fun isClientInstalled(context: Context): Boolean
    fun verifyFiles(context: Context): Boolean
    fun launch(context: Context, server: Server, character: Character, payloadJson: String): LaunchResult
}

/**
 * Запускает установленный клиент по его package name (AppConfig.CLIENT_PACKAGE) и передаёт параметры в Intent.
 * ВАЖНО: параметры (nickname/host/port) подхватит только клиент, который умеет их читать. Названия extras
 * ниже — условные, их нужно согласовать с вашим клиентом (или заменить на запись конфиг-файла клиента).
 */
class PackageGameLauncher : GameLauncher {
    private val pkg get() = AppConfig.CLIENT_PACKAGE
    override fun isClientInstalled(context: Context) =
        pkg.isNotBlank() && runCatching { context.packageManager.getPackageInfo(pkg, 0) }.isSuccess
    /** TODO: проверка игровых файлов (наличие/размер/хэш) — зависит от клиента и места хранения файлов. */
    override fun verifyFiles(context: Context) = true
    override fun launch(context: Context, server: Server, character: Character, payloadJson: String): LaunchResult {
        if (server.host.isNullOrBlank()) return LaunchResult.Failure("У сервера не задан адрес (host)")
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return LaunchResult.Failure("Не удалось получить запуск клиента")
        // Один JSON-extra: {"nickname","host","port","skin_id","ticket"}. Клиент должен читать "launch_json".
        intent.putExtra("launch_json", payloadJson)
        // Копируем одноразовый код в буфер: игрок вставит его в окне входа на сервере
        runCatching {
            val t = org.json.JSONObject(payloadJson).optString("ticket")
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("AVENRO", t))
        }
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { context.startActivity(intent); LaunchResult.Success }
        catch (e: Exception) { LaunchResult.Failure("Не удалось запустить клиент: ${e.message}") }
    }
}

// ---------- Updates ----------
interface UpdateChecker { suspend fun latestVersion(): String }
class DemoUpdateChecker : UpdateChecker { override suspend fun latestVersion(): String { delay(500); return "1.0.0" } }

// ---------- Settings ----------
class SettingsRepository(private val p: SharedPreferences) {
    var animations: Boolean
        get() = p.getBoolean("animations", true)
        set(v) = p.edit().putBoolean("animations", v).apply()
}

// ---------- DI ----------
object ServiceLocator {
    lateinit var settings: SettingsRepository
    lateinit var session: SessionStore
    lateinit var auth: AuthRepository
    lateinit var accounts: AccountRepository
    lateinit var servers: ServerRepository
    lateinit var news: NewsRepository
    lateinit var characters: CharacterRepository
    lateinit var config: ConfigRepository
    lateinit var tickets: LaunchTicketRepository
    val launcher: GameLauncher = PackageGameLauncher()
    val updates: UpdateChecker = DemoUpdateChecker()

    fun init(c: Context) {
        settings = SettingsRepository(c.getSharedPreferences("avenro", Context.MODE_PRIVATE))
        session = SessionStore(c.getSharedPreferences("session", Context.MODE_PRIVATE))
        val api = buildApi(session)
        auth = AuthRepository(api, session)
        accounts = RemoteAccountRepository(api)
        servers = RemoteServerRepository(api)
        news = RemoteNewsRepository(api)
        characters = RemoteCharacterRepository(api)
        config = ConfigRepository(api)
        tickets = LaunchTicketRepository(api)
    }
}
