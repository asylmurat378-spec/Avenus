package com.avenro.launcher.install

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import com.avenro.launcher.data.AppConfig
import com.google.gson.Gson
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import kotlin.coroutines.coroutineContext

/**
 * Скачивает APK игры и кэш (OBB / data), проверяет SHA-256, распаковывает и ставит APK через PackageInstaller.
 * Состояние — в [state], UI (InstallOverlay) только подписывается на него.
 */
object GameInstaller {
    private const val RESERVE = 300L * 1024 * 1024          // запас свободного места
    private val _state = MutableStateFlow<InstallState>(InstallState.Idle)
    val state: StateFlow<InstallState> = _state

    private var job: Job? = null
    @Volatile private var plan: Plan? = null
    @Volatile private var activeCall: Call? = null

    private val gson = Gson()
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private val pkgRe = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$")
    private val shaRe = Regex("^[0-9a-fA-F]{64}$")

    val isBusy: Boolean get() = _state.value.let { it is InstallState.Working || it is InstallState.NeedsConfirm }

    // ===================== ПОДГОТОВКА =====================

    /** Загружает манифест и решает, что нужно скачать/установить. Ничего не скачивает. */
    suspend fun prepare(ctx: Context): Plan = withContext(Dispatchers.IO) {
        val url = AppConfig.GAME_MANIFEST_URL
        if (!url.startsWith("https://")) throw InstallException("Не задана ссылка на манифест игры (game_manifest_url)")
        val body = http.newCall(Request.Builder().url(url).header("Cache-Control", "no-cache").build()).execute().use { r ->
            if (!r.isSuccessful) throw InstallException("Не удалось получить манифест игры (${r.code})")
            r.body?.string() ?: throw InstallException("Пустой манифест игры")
        }
        val parsed = try { gson.fromJson(body, GameManifest::class.java) } catch (e: Exception) { null }
        val m = validate(parsed)
        AppConfig.CLIENT_PACKAGE = m.pkg
        val installed = installedVersion(ctx, m.pkg)
        Plan(m, installed < m.versionCode, m.files.filterNot { isFileOk(ctx, m, it) })
    }

    private fun validate(m: GameManifest?): GameManifest {
        fun bad(why: String): Nothing = throw InstallException("Манифест игры: $why")
        if (m == null) bad("пустой или повреждён")
        if (!pkgRe.matches(m.pkg)) bad("неверный package")
        if (m.versionCode <= 0) bad("version_code должен быть > 0")
        val a = m.apk
        if (!a.url.startsWith("https://") || !shaRe.matches(a.sha256) || a.size <= 0) bad("неверное описание apk")
        for (f in m.files) {
            if (!f.url.startsWith("https://") || !shaRe.matches(f.sha256) || f.size <= 0) bad("неверное описание файла ${f.path}")
            if (f.dest != "obb" && f.dest != "data" && f.dest != "launcher") bad("неизвестный dest '${f.dest}'")
            if (f.path.contains("..") || f.path.startsWith("/") || f.path.contains("\\")) bad("небезопасный путь '${f.path}'")
            if (!f.unzip && f.path.isBlank()) bad("у файла нет path")
        }
        return m
    }

    private fun installedVersion(ctx: Context, pkg: String): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(pkg, 0))
    } catch (e: PackageManager.NameNotFoundException) { -1L }

    private fun destDir(ctx: Context, pkg: String, dest: String): File {
        @Suppress("DEPRECATION") val root = Environment.getExternalStorageDirectory()
        return when (dest) {
            "obb" -> File(root, "Android/obb/$pkg")
            "data" -> File(root, "Android/data/$pkg/files")
            else -> File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "game")
        }
    }
    private fun downloadsDir(ctx: Context) = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "downloads")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("installer", Context.MODE_PRIVATE)
    private fun key(m: GameManifest, f: FileEntry) = "${m.pkg}|${f.dest}|${f.path}|${f.url.hashCode()}"

    /** Быстрая проверка по записи об успешной установке (без пересчёта хэша: файлы бывают по несколько ГБ). */
    private fun isFileOk(ctx: Context, m: GameManifest, f: FileEntry): Boolean {
        if (prefs(ctx).getString(key(m, f), null) != f.sha256.lowercase()) return false
        if (!f.unzip) {
            val t = File(destDir(ctx, m.pkg, f.dest), f.path)
            if (t.exists()) { if (t.length() != f.size) return false }
            else if (Build.VERSION.SDK_INT < 30) return false   // на Android 11+ папку чужого приложения можно не видеть
        }
        return true
    }

    // ===================== ЗАПУСК / ОТМЕНА =====================

    fun start(ctx: Context, p: Plan) {
        plan = p
        _state.value = InstallState.Working(Stage.PREPARE, "Подготовка…", 0, p.bytes, 0)
        ContextCompat.startForegroundService(ctx, Intent(ctx, InstallService::class.java))
    }

    /** Вызывается из InstallService. */
    fun launchJob(scope: CoroutineScope, ctx: Context, onEnd: () -> Unit) {
        if (job?.isActive == true) return
        val p = plan ?: return onEnd()
        job = scope.launch { try { execute(ctx, p) } finally { onEnd() } }
    }

    fun cancel() {
        job?.cancel(); activeCall?.cancel()
        _state.value = InstallState.Idle
    }

    /** Сбросить Done/Failed в Idle (во время работы ничего не делает). */
    fun reset() { if (!isBusy) _state.value = InstallState.Idle }

    // ===================== ОСНОВНОЙ ПРОЦЕСС =====================

    private class Tracker(val stage: Stage, val label: String, val total: Long) {
        var base = 0L
        private var lastT = SystemClock.elapsedRealtime()
        private var lastB = -1L
        private var speed = 0L
        fun report(cur: Long, force: Boolean = false) {
            val now = SystemClock.elapsedRealtime()
            val done = base + cur
            if (lastB < 0) lastB = done
            if (!force && now - lastT < 300) return
            val dt = now - lastT
            if (dt > 0) {
                val inst = (done - lastB) * 1000 / dt
                speed = if (speed == 0L) inst else (speed * 0.6 + inst * 0.4).toLong()
            }
            lastT = now; lastB = done
            _state.value = InstallState.Working(stage, label, done, total, speed)
        }
    }

    suspend fun execute(ctx: Context, p: Plan) = withContext(Dispatchers.IO) {
        plan = p
        val m = p.manifest
        try {
            val dl = downloadsDir(ctx).apply { mkdirs() }
            checkSpace(dl, p)
            val apkFile = File(dl, "client.apk")

            // 1) Загрузка
            val dt = Tracker(Stage.DOWNLOAD, "Игровые файлы", p.bytes)
            if (p.installApk) { download(m.apk.url, apkFile, m.apk.size, dt); dt.base += m.apk.size }
            val placed = ArrayList<Pair<FileEntry, File>>()
            for (f in p.files) {
                val dir = destDir(ctx, m.pkg, f.dest)
                if (!dir.exists() && !dir.mkdirs()) {
                    throw InstallException("Нет доступа к папке ${dir.path}. Разрешите лаунчеру установку приложений (на Android 11+ это даёт доступ к Android/obb)")
                }
                val target = if (f.unzip) File(dl, "pack_${f.sha256.take(8)}.zip") else File(dir, f.path)
                download(f.url, target, f.size, dt); dt.base += f.size
                placed += f to target
            }

            // 2) Проверка SHA-256
            val vt = Tracker(Stage.VERIFY, "Контрольные суммы", p.bytes)
            if (p.installApk) { verifyHash(apkFile, m.apk.sha256, vt); vt.base += m.apk.size }
            for ((f, file) in placed) { verifyHash(file, f.sha256, vt); vt.base += f.size }

            // 3) Распаковка и запись об успешной установке файла
            for ((f, file) in placed) {
                if (f.unzip) {
                    val ut = Tracker(Stage.UNPACK, "Данные игры", maxOf(f.unzippedSize, 1L))
                    unzip(file, destDir(ctx, m.pkg, f.dest), ut)
                    file.delete()
                }
                prefs(ctx).edit().putString(key(m, f), f.sha256.lowercase()).apply()
            }

            // 4) Установка APK (результат придёт в InstallResultReceiver)
            if (p.installApk) {
                checkApk(ctx, apkFile, m.pkg)
                _state.value = InstallState.Working(Stage.INSTALL, "Установка игры", 0, 0, 0)
                commitInstall(ctx, apkFile)
            } else {
                _state.value = InstallState.Done
            }
        } catch (e: CancellationException) {
            _state.value = InstallState.Idle
            throw e
        } catch (e: Exception) {
            _state.value = if (!coroutineContext.isActive) InstallState.Idle else InstallState.Failed(userMessage(e))
        }
        Unit
    }

    private fun userMessage(e: Exception): String = when {
        e is InstallException -> e.message ?: "Ошибка установки"
        e is FileNotFoundException || e is SecurityException ->
            "Нет доступа к папке игры. Разрешите лаунчеру установку приложений; на Android 13+ папка Android/data недоступна — используйте OBB"
        e is IOException && (e.message ?: "").contains("ENOSPC") -> "Недостаточно места на устройстве"
        e is IOException -> "Ошибка сети или записи файла: ${e.message ?: "нет соединения"}"
        else -> e.message ?: "Неизвестная ошибка"
    }

    private fun checkSpace(dl: File, p: Plan) {
        var need = RESERVE + (if (p.installApk) p.manifest.apk.size else 0L)
        for (f in p.files) need += f.size + (if (f.unzip) f.unzippedSize else 0L)
        val free = StatFs(dl.path).availableBytes
        if (free < need) throw InstallException("Недостаточно места: нужно ${fmtBytes(need)}, свободно ${fmtBytes(free)}")
    }

    // ===================== ЗАГРУЗКА С ДОКАЧКОЙ =====================

    private suspend fun download(url: String, out: File, size: Long, t: Tracker) {
        out.parentFile?.mkdirs()
        if (out.exists() && out.length() == size) { t.report(size, true); return }   // уже скачан
        val part = File(out.path + ".part")
        var have = if (part.exists()) part.length() else 0L
        if (have > size) { part.delete(); have = 0 }
        if (have < size) {
            val call = http.newCall(Request.Builder().url(url).apply { if (have > 0) header("Range", "bytes=$have-") }.build())
            activeCall = call
            call.execute().use { r ->
                if (r.code == 416) { part.delete(); throw InstallException("Сервер отклонил докачку. Нажмите «Играть» ещё раз") }
                if (!r.isSuccessful) throw InstallException("Ошибка загрузки (${r.code})")
                val append = r.code == 206 && have > 0
                if (!append) have = 0
                val body = r.body ?: throw InstallException("Пустой ответ сервера")
                t.report(have, true)
                FileOutputStream(part, append).use { os ->
                    val buf = ByteArray(256 * 1024)
                    var cur = have
                    body.byteStream().use { ins ->
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n); cur += n; t.report(cur)
                        }
                    }
                }
            }
            activeCall = null
        }
        if (part.length() != size) throw InstallException("Файл ${out.name} загружен не полностью, повторите")
        out.delete()
        if (!part.renameTo(out)) { part.copyTo(out, true); part.delete() }
        t.report(size, true)
    }

    // ===================== ХЭШ И РАСПАКОВКА =====================

    private suspend fun sha256(f: File, t: Tracker?): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { ins ->
            val buf = ByteArray(256 * 1024)
            var cur = 0L
            while (true) {
                coroutineContext.ensureActive()
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n); cur += n; t?.report(cur)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private suspend fun verifyHash(f: File, expected: String, t: Tracker) {
        if (sha256(f, t) != expected.lowercase()) {
            f.delete()
            throw InstallException("Файл ${f.name} повреждён (контрольная сумма не совпала). Нажмите «Повторить», чтобы скачать заново")
        }
    }

    private suspend fun unzip(zip: File, destDir: File, t: Tracker) {
        destDir.mkdirs()
        val root = destDir.canonicalPath + File.separator
        var cur = 0L
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zin ->
            var e = zin.nextEntry
            val buf = ByteArray(256 * 1024)
            while (e != null) {
                coroutineContext.ensureActive()
                val outFile = File(destDir, e.name)
                if (!outFile.canonicalPath.startsWith(root)) throw InstallException("Небезопасный архив данных")
                if (e.isDirectory) outFile.mkdirs()
                else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { os ->
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = zin.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n); cur += n; t.report(cur)
                        }
                    }
                }
                zin.closeEntry(); e = zin.nextEntry
            }
        }
    }

    // ===================== УСТАНОВКА APK =====================

    /** Проверяет имя пакета и (если задан client_cert_sha256) подпись APK до установки. */
    private fun checkApk(ctx: Context, apk: File, pkg: String) {
        @Suppress("DEPRECATION")
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val info = ctx.packageManager.getPackageArchiveInfo(apk.path, flags) ?: throw InstallException("APK повреждён")
        if (info.packageName != pkg) throw InstallException("APK принадлежит другому приложению (${info.packageName})")
        val pin = AppConfig.CLIENT_CERT_SHA256.lowercase()
        if (pin.isNotBlank()) {
            @Suppress("DEPRECATION")
            val sigs = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners else info.signatures
            val ok = sigs?.any { s ->
                MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) } == pin
            } == true
            if (!ok) { apk.delete(); throw InstallException("Подпись клиента не совпала с ожидаемой. Установка отменена") }
        }
    }

    private fun commitInstall(ctx: Context, apk: File) {
        val pi = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setSize(apk.length())
            if (Build.VERSION.SDK_INT >= 31) setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        val id = pi.createSession(params)
        pi.openSession(id).use { s ->
            apk.inputStream().use { ins ->
                s.openWrite("client.apk", 0, apk.length()).use { os -> ins.copyTo(os); s.fsync(os) }
            }
            val i = Intent(ctx, InstallResultReceiver::class.java).setAction(InstallResultReceiver.ACTION)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(ctx, id, i, flags).intentSender)
        }
    }

    // ===================== СОБЫТИЯ ОТ InstallResultReceiver =====================

    fun onNeedsConfirm(i: Intent) { _state.value = InstallState.NeedsConfirm(i) }

    fun onInstalled(ctx: Context) {
        runCatching { File(downloadsDir(ctx), "client.apk").delete() }
        val p = plan
        val ok = p == null || installedVersion(ctx, p.manifest.pkg) >= p.manifest.versionCode
        _state.value = if (ok) InstallState.Done
            else InstallState.Failed("Установка завершилась, но версия игры не обновилась")
    }

    fun onInstallFailed(code: Int, msg: String?) {
        _state.value = InstallState.Failed(when (code) {
            PackageInstaller.STATUS_FAILURE_ABORTED -> "Установка отменена"
            PackageInstaller.STATUS_FAILURE_CONFLICT ->
                "Конфликт с установленной версией (другая подпись). Удалите старую версию игры и повторите"
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> "APK несовместим с этим устройством"
            PackageInstaller.STATUS_FAILURE_STORAGE -> "Недостаточно места для установки"
            PackageInstaller.STATUS_FAILURE_BLOCKED -> "Установка заблокирована системой или защитой устройства"
            else -> "Ошибка установки (${msg ?: code})"
        })
    }

    // ===================== ПРОВЕРКА ФАЙЛОВ (Настройки) =====================

    /** Глубокая проверка: пересчитывает SHA-256 файлов кэша; битые удаляются и будут скачаны при «Играть». */
    suspend fun repair(ctx: Context): String = withContext(Dispatchers.IO) {
        val p = prepare(ctx)
        var checked = 0; var bad = 0
        for (f in p.manifest.files) {
            if (f.unzip) continue
            val t = File(destDir(ctx, p.manifest.pkg, f.dest), f.path)
            if (!t.exists()) continue
            checked++
            if (sha256(t, null) != f.sha256.lowercase()) {
                t.delete(); prefs(ctx).edit().remove(key(p.manifest, f)).apply(); bad++
            }
        }
        when {
            bad > 0 -> "Повреждённых файлов: $bad. Нажмите «Играть», чтобы скачать их заново"
            p.needsWork -> "Нужна установка или обновление игры: нажмите «Играть»"
            else -> "Файлы игры в порядке (проверено: $checked)"
        }
    }
}
