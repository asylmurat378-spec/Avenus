package com.avenro.launcher

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.avenro.launcher.data.ServiceLocator
import com.avenro.launcher.ui.*

class MainActivity : ComponentActivity() {
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ServiceLocator.init(applicationContext)
        // Уведомление о загрузке (Android 13+) и запись в Android/obb (Android 9-10)
        val need = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT <= 29) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
        setContent { AvenroTheme { App() } }
    }
}

@Composable
fun App(vm: LauncherViewModel = viewModel()) {
    val loggedIn by vm.loggedIn.collectAsStateWithLifecycle()
    val nav = rememberNavController()
    val msg by vm.message.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.clearMessage() } }
    LaunchedEffect(loggedIn) { if (!loggedIn) nav.popBackStack("main", false) }
    Box {
        NavHost(nav, "main", enterTransition = { fadeIn() }, exitTransition = { fadeOut() },
            popEnterTransition = { fadeIn() }, popExitTransition = { fadeOut() }) {
            composable("main") { MainScreen(vm, { nav.navigate("servers") }, { nav.navigate("settings") }, vm::logout) }
            composable("servers") { ServersScreen(vm, { nav.popBackStack() }, { nav.navigate("characters") }) }
            composable("characters") { CharactersScreen(vm, { nav.popBackStack() }, { nav.navigate("create") }) }
            composable("create") { CreateCharacterScreen(vm) { nav.popBackStack() } }
            composable("settings") { SettingsScreen(vm) { nav.popBackStack() } }
        }
        if (!loggedIn) AuthScreen(vm)
        InstallOverlay { vm.play(it) }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter))
    }
}
