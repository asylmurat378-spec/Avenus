package com.avenro.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.avenro.launcher.data.ServiceLocator
import com.avenro.launcher.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ServiceLocator.init(applicationContext)
        setContent { AvenroTheme { App(onExit = { finishAffinity() }) } }
    }
}

@Composable
fun App(onExit: () -> Unit, vm: LauncherViewModel = viewModel()) {
    val nav = rememberNavController()
    val msg by vm.message.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.clearMessage() } }
    Box {
        NavHost(nav, "main", enterTransition = { fadeIn() }, exitTransition = { fadeOut() },
            popEnterTransition = { fadeIn() }, popExitTransition = { fadeOut() }) {
            composable("main") { MainScreen(vm, { nav.navigate("servers") }, { nav.navigate("settings") }, onExit) }
            composable("servers") { ServersScreen(vm, { nav.popBackStack() }, { nav.navigate("characters") }) }
            composable("characters") { CharactersScreen(vm, { nav.popBackStack() }, { nav.navigate("create") }) }
            composable("create") { CreateCharacterScreen(vm) { nav.popBackStack() } }
            composable("settings") { SettingsScreen(vm) { nav.popBackStack() } }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter))
    }
}
