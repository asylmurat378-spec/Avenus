package com.avenro.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Black = Color(0xFF09090D)
val Graphite = Color(0xFF191820)
val Purple = Color(0xFF922EFF)
val PurpleDark = Color(0xFF6A1FCC)
val Gray = Color(0xFF9A98A6)
val Green = Color(0xFF3DDC84)

@Composable
fun AvenroTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Purple, background = Black, surface = Graphite,
        onSurface = Color.White, onBackground = Color.White),
    content = content
)

fun Modifier.pressable(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.97f else 1f, label = "press")
    this.scale(s).clickable(src, null, enabled = enabled, onClick = onClick)
}

@Composable
fun ScreenBg(content: @Composable BoxScope.() -> Unit) = Box(
    Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Graphite, Black)))
        .background(Brush.radialGradient(listOf(Purple.copy(alpha = 0.18f), Color.Transparent), radius = 900f)),
    content = content
)

@Composable
fun PrimaryButton(text: String, icon: ImageVector? = null, modifier: Modifier = Modifier,
                  enabled: Boolean = true, big: Boolean = false, onClick: () -> Unit) {
    Row(
        modifier.pressable(enabled, onClick).clip(RoundedCornerShape(16.dp))
            .background(if (enabled) Brush.horizontalGradient(listOf(Purple, PurpleDark))
                        else Brush.horizontalGradient(listOf(Graphite, Graphite)))
            .padding(horizontal = 24.dp, vertical = if (big) 16.dp else 12.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(if (big) 30.dp else 22.dp)); Spacer(Modifier.width(10.dp)) }
        Text(text, color = if (enabled) Color.White else Gray, fontSize = if (big) 24.sp else 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Header(title: String, onBack: () -> Unit, right: @Composable () -> Unit = {}) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 14.dp)) {
        Row(Modifier.align(Alignment.CenterStart).pressable(onClick = onBack), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
            Spacer(Modifier.width(8.dp)); Text("Назад", color = Color.White, fontSize = 14.sp)
        }
        Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(5.dp).height(22.dp).background(Purple)); Spacer(Modifier.width(10.dp))
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.align(Alignment.CenterEnd)) { right() }
    }
}

@Composable
fun Loading() = Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Purple) }

@Composable
fun ErrorBox(msg: String, retry: () -> Unit) = Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
    Text(msg, color = Gray); Spacer(Modifier.height(12.dp)); PrimaryButton("Повторить", onClick = retry)
}
