package com.avenro.launcher.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.avenro.launcher.data.*

private val cardShape = RoundedCornerShape(18.dp)

// ===================== MAIN =====================
@Composable
fun MainScreen(vm: LauncherViewModel, onPlay: () -> Unit, onSettings: () -> Unit, onExit: () -> Unit) {
    val account = (vm.account.collectAsStateWithLifecycle().value as? Ui.Ok)?.v
    val news = (vm.news.collectAsStateWithLifecycle().value as? Ui.Ok)?.v?.firstOrNull()
    val anim by vm.animations.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val uri = LocalUriHandler.current
    var showNews by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }

    ScreenBg {
        Row(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxHeight().padding(20.dp)) {
                // Аккаунт + баланс
                Row(Modifier.align(Alignment.TopStart), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.clip(RoundedCornerShape(30.dp)).background(Graphite.copy(alpha = .85f)).padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Avatar(account?.avatarUrl, 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("ID: ${account?.id ?: "…"}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        IconButton(onClick = { account?.let { clipboard.setText(AnnotatedString(it.id)) } }) {
                            Icon(Icons.Default.ContentCopy, "Копировать ID", tint = Color.White)
                        }
                    }
                    Spacer(Modifier.width(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(36.dp).clip(CircleShape).background(Purple), Alignment.Center) {
                            Icon(Icons.Default.Diamond, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("ДК  ${account?.donateCoins?.let { "%,d".format(it).replace(',', ' ') } ?: "…"}",
                            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        IconButton(onClick = { uri.openUri(AppConfig.DONATE_URL) }) {
                            Icon(Icons.Default.Add, "Пополнить", tint = Color.White)
                        }
                    }
                }
                // Центр
                Column(Modifier.align(Alignment.Center).padding(top = 36.dp, bottom = 52.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.WorkspacePremium, null, tint = Purple, modifier = Modifier.size(30.dp))
                    Text("AVENRO", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                    Text("ROLEPLAY", color = Purple, fontSize = 20.sp, fontWeight = FontWeight.Black,
                        fontStyle = FontStyle.Italic, letterSpacing = 6.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("СОЗДАЙ СВОЮ ИСТОРИЮ", color = Gray, fontSize = 11.sp, letterSpacing = 5.sp)
                    Spacer(Modifier.height(12.dp))
                    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
                        1f, if (anim) 1.04f else 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "pulse")
                    PrimaryButton("ИГРАТЬ", Icons.Default.PlayArrow, Modifier.scale(pulse).width(280.dp), big = true, onClick = onPlay)
                }
                // Новости
                Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().clip(RoundedCornerShape(30.dp))
                    .background(Graphite.copy(alpha = .85f)).pressable(enabled = news != null) { showNews = true }
                    .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Campaign, null, tint = Purple)
                    Spacer(Modifier.width(10.dp))
                    Text("НОВОСТИ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.width(16.dp))
                    Text(news?.title ?: "Загрузка…", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                    Text(news?.date ?: "", color = Gray, fontSize = 12.sp)
                    Icon(Icons.Default.ChevronRight, null, tint = Purple)
                }
            }
            // Правая панель
            Column(Modifier.width(260.dp).fillMaxHeight().background(Black.copy(alpha = .92f)).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(5.dp).height(22.dp).background(Purple)); Spacer(Modifier.width(10.dp))
                    Text("ИНТЕГРАЦИИ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.height(16.dp))
                IntegrationCard("Discord", null, Icons.Default.SportsEsports, true) { uri.openUri(AppConfig.DISCORD_URL) }
                Spacer(Modifier.height(12.dp))
                IntegrationCard("Telegram", null, Icons.Default.Send, true) { uri.openUri(AppConfig.TELEGRAM_URL) }
                Spacer(Modifier.height(12.dp))
                IntegrationCard("Форум", "(в разработке)", Icons.Default.Forum, AppConfig.FORUM_ENABLED) {}
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextIcon("Настройки", Icons.Default.Settings, onSettings)
                    TextIcon("Выход", Icons.AutoMirrored.Filled.Logout) { confirmExit = true }
                }
            }
        }
    }
    if (showNews && news != null) AlertDialog(onDismissRequest = { showNews = false },
        confirmButton = { TextButton({ showNews = false }) { Text("Закрыть", color = Purple) } },
        title = { Text(news.title) }, text = { Text("${news.summary}\n\n${news.date}") },
        containerColor = Graphite)
    if (confirmExit) AlertDialog(onDismissRequest = { confirmExit = false },
        confirmButton = { TextButton(onExit) { Text("Выйти", color = Purple) } },
        dismissButton = { TextButton({ confirmExit = false }) { Text("Отмена", color = Gray) } },
        title = { Text("Выход из аккаунта") }, text = { Text("Вы действительно хотите выйти?") }, containerColor = Graphite)
}

@Composable private fun Avatar(url: String?, size: androidx.compose.ui.unit.Dp) =
    Box(Modifier.size(size).clip(CircleShape).background(Black).border(1.dp, Gray, CircleShape), Alignment.Center) {
        if (url != null) AsyncImage(url, null, Modifier.fillMaxSize())
        else Icon(Icons.Default.Person, null, tint = Gray)
    }

@Composable private fun IntegrationCard(title: String, sub: String?, icon: ImageVector, enabled: Boolean, onClick: () -> Unit) =
    Row(Modifier.fillMaxWidth().clip(cardShape).background(Graphite).pressable(enabled, onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (enabled) Color.White else Gray, modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (enabled) Color.White else Gray, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            if (sub != null) Text(sub, color = Gray, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Gray)
    }

@Composable private fun TextIcon(t: String, i: ImageVector, onClick: () -> Unit) =
    Row(Modifier.pressable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Icon(i, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp))
        Text(t, color = Color.White, fontSize = 13.sp)
    }

// ===================== SERVERS =====================
@Composable
fun ServersScreen(vm: LauncherViewModel, onBack: () -> Unit, onNext: () -> Unit) {
    val state by vm.servers.collectAsStateWithLifecycle()
    val sel by vm.selectedServer.collectAsStateWithLifecycle()
    val account = (vm.account.collectAsStateWithLifecycle().value as? Ui.Ok)?.v
    ScreenBg {
        Column(Modifier.fillMaxSize()) {
            Header("ВЫБОР СЕРВЕРА", onBack) { Text("ID: ${account?.id ?: ""}", color = Color.White, fontSize = 12.sp) }
            Box(Modifier.weight(1f).padding(horizontal = 24.dp)) {
                when (val s = state) {
                    Ui.Loading -> Loading()
                    is Ui.Err -> ErrorBox(s.msg, vm::loadServers)
                    is Ui.Ok -> if (s.v.isEmpty()) ErrorBox("Нет доступных серверов", vm::loadServers)
                    else Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        s.v.forEach { sv ->
                            val selected = sel?.id == sv.id
                            Box(Modifier.weight(1f).fillMaxHeight(.8f).tapSelect(selected) {
                                if (selected) onNext() else vm.selectServer(sv) }) { ServerCard(sv, selected) }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Graphite.copy(alpha = .7f)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, null, tint = Gray, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp))
                    Text("Доступно только активные сервера", color = Gray, fontSize = 12.sp)
                }
                Spacer(Modifier.width(24.dp))
                PrimaryButton("Выбрать сервер", Icons.AutoMirrored.Filled.ArrowForward, Modifier.width(260.dp),
                    enabled = sel != null, onClick = onNext)
            }
        }
    }
}

private fun Modifier.tapSelect(selected: Boolean, onClick: () -> Unit) = this.pressable(onClick = onClick)

@Composable
private fun ServerCard(s: Server, selected: Boolean) {
    val border by animateColorAsState(if (selected) Purple else Color.White.copy(alpha = .1f), label = "b")
    Box(Modifier.fillMaxSize().clip(cardShape).border(if (selected) 3.dp else 1.dp, border, cardShape)
        .background(Brush.verticalGradient(listOf(Color(0xFF2A1F44), Black)))) {
        if (s.imageUrl != null) AsyncImage(s.imageUrl, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Black.copy(alpha = .85f)))))
        if (selected) CheckBadge(Modifier.align(Alignment.TopEnd).padding(10.dp))
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text(s.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(Green)); Spacer(Modifier.width(8.dp))
                Text("Онлайн: ${"%,d".format(s.online).replace(',', ' ')}", color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

@Composable private fun CheckBadge(m: Modifier) =
    Box(m.size(26.dp).clip(CircleShape).background(Purple), Alignment.Center) {
        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
    }

// ===================== CHARACTERS =====================
@Composable
fun CharactersScreen(vm: LauncherViewModel, onBack: () -> Unit, onCreate: () -> Unit) {
    val state by vm.slots.collectAsStateWithLifecycle()
    val sel by vm.selectedSlot.collectAsStateWithLifecycle()
    val launching by vm.launching.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.loadSlots() }
    ScreenBg {
        Column(Modifier.fillMaxSize()) {
            Header("ВЫБОР ПЕРСОНАЖА", onBack)
            Box(Modifier.weight(1f).padding(horizontal = 48.dp)) {
                when (val s = state) {
                    Ui.Loading -> Loading()
                    is Ui.Err -> ErrorBox(s.msg, vm::loadSlots)
                    is Ui.Ok -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        s.v.forEachIndexed { i, c ->
                            Box(Modifier.weight(1f).fillMaxHeight(.92f)) {
                                if (c == null) EmptySlot(onCreate) else CharacterCard(c, sel == i) { vm.selectSlot(i) }
                            }
                        }
                    }
                }
            }
            Box(Modifier.fillMaxWidth().padding(bottom = 20.dp), Alignment.Center) {
                PrimaryButton(if (launching) "Запуск…" else "Играть", Icons.Default.PlayArrow, Modifier.width(380.dp), enabled = sel != null && !launching, big = true) { vm.play(ctx) }
            }
        }
    }
}

@Composable
private fun CharacterCard(c: Character, selected: Boolean, onClick: () -> Unit) {
    val border by animateColorAsState(if (selected) Purple else Color.White.copy(alpha = .1f), label = "b")
    Box(Modifier.fillMaxSize().pressable(onClick = onClick).clip(cardShape)
        .border(if (selected) 3.dp else 1.dp, border, cardShape)
        .background(Brush.verticalGradient(listOf(Color(0xFF2A1F44), Black)))) {
        if (c.imageUrl != null) AsyncImage(c.imageUrl, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        else Icon(Icons.Default.Person, null, tint = Gray.copy(alpha = .5f), modifier = Modifier.align(Alignment.Center).size(110.dp))
        if (selected) CheckBadge(Modifier.align(Alignment.TopEnd).padding(10.dp))
        Column(Modifier.align(Alignment.BottomCenter).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${c.firstName} ${c.lastName}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Уровень: ${c.level}", color = Gray, fontSize = 13.sp)
        }
    }
}

@Composable
private fun EmptySlot(onCreate: () -> Unit) = Column(
    Modifier.fillMaxSize().pressable(onClick = onCreate).clip(cardShape)
        .border(1.dp, Purple.copy(alpha = .5f), cardShape).background(Graphite.copy(alpha = .6f)),
    Arrangement.Center, Alignment.CenterHorizontally) {
    Icon(Icons.Default.PersonAdd, null, tint = Purple, modifier = Modifier.size(56.dp))
    Spacer(Modifier.height(10.dp))
    Text("Свободный слот", color = Gray, fontSize = 13.sp)
    Text("Создать персонажа", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
}

// ===================== CREATE =====================
@Composable
fun CreateCharacterScreen(vm: LauncherViewModel, onBack: () -> Unit) {
    var first by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("M") }
    val creating by vm.creating.collectAsStateWithLifecycle()
    val valid = first.trim().length >= 2 && last.trim().length >= 2
    val colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Gray,
        focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Purple)
    ScreenBg {
        Column(Modifier.fillMaxSize()) {
            Header("СОЗДАНИЕ ПЕРСОНАЖА", onBack)
            Column(Modifier.align(Alignment.CenterHorizontally).width(460.dp).padding(top = 12.dp)) {
                OutlinedTextField(first, { first = it.filter(Char::isLetter) }, Modifier.fillMaxWidth(),
                    label = { Text("Имя") }, singleLine = true, colors = colors)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(last, { last = it.filter(Char::isLetter) }, Modifier.fillMaxWidth(),
                    label = { Text("Фамилия") }, singleLine = true, colors = colors)
                Spacer(Modifier.height(16.dp))
                Text("Пол", color = Gray, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("M" to "Мужской", "F" to "Женский").forEach { (k, v) ->
                        FilterChip(gender == k, { gender = k }, { Text(v) }, colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Purple, selectedLabelColor = Color.White, labelColor = Gray))
                    }
                }
                Spacer(Modifier.height(20.dp))
                PrimaryButton(if (creating) "Создание…" else "Создать", modifier = Modifier.fillMaxWidth(), enabled = valid && !creating) {
                    vm.createCharacter(first.trim(), last.trim(), gender, onBack)
                }
            }
        }
    }
}

// ===================== SETTINGS =====================
@Composable
fun SettingsScreen(vm: LauncherViewModel, onBack: () -> Unit) {
    val anim by vm.animations.collectAsStateWithLifecycle()
    ScreenBg {
        Column(Modifier.fillMaxSize()) {
            Header("НАСТРОЙКИ", onBack)
            Column(Modifier.align(Alignment.CenterHorizontally).width(460.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth().clip(cardShape).background(Graphite).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Анимации", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(anim, vm::setAnimations, colors = SwitchDefaults.colors(checkedTrackColor = Purple))
                }
                Row(Modifier.fillMaxWidth().clip(cardShape).background(Graphite).pressable { vm.checkUpdates() }.padding(16.dp)) {
                    Text("Проверить обновления", color = Color.White, modifier = Modifier.weight(1f))
                    Text("v1.0.0", color = Gray)
                }
            }
        }
    }
}
