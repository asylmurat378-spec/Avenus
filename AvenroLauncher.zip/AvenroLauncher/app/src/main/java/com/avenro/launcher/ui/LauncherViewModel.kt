package com.avenro.launcher.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avenro.launcher.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface Ui<out T> {
    object Loading : Ui<Nothing>
    data class Ok<T>(val v: T) : Ui<T>
    data class Err(val msg: String) : Ui<Nothing>
}

class LauncherViewModel : ViewModel() {
    private val sl = ServiceLocator
    val account = MutableStateFlow<Ui<Account>>(Ui.Loading)
    val news = MutableStateFlow<Ui<List<NewsItem>>>(Ui.Loading)
    val servers = MutableStateFlow<Ui<List<Server>>>(Ui.Loading)
    val slots = MutableStateFlow<Ui<List<Character?>>>(Ui.Loading)
    val selectedServer = MutableStateFlow<Server?>(null)
    val selectedSlot = MutableStateFlow<Int?>(null)
    val animations = MutableStateFlow(sl.settings.animations)
    val message = MutableStateFlow<String?>(null)
    val creating = MutableStateFlow(false)
    val launching = MutableStateFlow(false)

    val loggedIn: StateFlow<Boolean> = sl.session.loggedIn
    val authBusy = MutableStateFlow(false)
    val authError = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch { runCatching { sl.config.load() } }
        viewModelScope.launch { sl.session.loggedIn.collect { on -> if (on) loadAll() else resetAll() } }
    }
    private fun loadAll() { loadAccount(); loadNews(); loadServers() }
    private fun resetAll() {
        account.value = Ui.Loading; news.value = Ui.Loading; servers.value = Ui.Loading; slots.value = Ui.Loading
        selectedServer.value = null; selectedSlot.value = null
    }
    fun signIn(email: String, pw: String) {
        authBusy.value = true; authError.value = null
        viewModelScope.launch {
            try { sl.auth.signIn(email.trim(), pw) } catch (e: Exception) { authError.value = e.toUserMessage() }
            authBusy.value = false
        }
    }
    fun signUp(email: String, pw: String, nick: String) {
        authBusy.value = true; authError.value = null
        viewModelScope.launch {
            try {
                if (!sl.auth.signUp(email.trim(), pw, nick.trim())) authError.value = "Аккаунт создан. Подтвердите почту и войдите."
            } catch (e: Exception) { authError.value = e.toUserMessage() }
            authBusy.value = false
        }
    }
    fun logout() = sl.auth.signOut()

    private fun <T> load(f: MutableStateFlow<Ui<T>>, block: suspend () -> T) {
        f.value = Ui.Loading
        viewModelScope.launch {
            f.value = try { Ui.Ok(block()) } catch (e: Exception) { Ui.Err(e.toUserMessage()) }
        }
    }
    fun loadAccount() = load(account) { sl.accounts.account() }
    fun loadNews() = load(news) { sl.news.news() }
    fun loadServers() = load(servers) { sl.servers.servers() }
    fun selectServer(s: Server) { selectedServer.value = s }
    fun loadSlots() {
        val s = selectedServer.value ?: return
        selectedSlot.value = null
        load(slots) { sl.characters.slots(s.id) }
    }
    fun selectSlot(i: Int) { selectedSlot.value = i }

    fun createCharacter(first: String, last: String, gender: String, done: () -> Unit) {
        val s = selectedServer.value ?: return
        creating.value = true
        viewModelScope.launch {
            try { sl.characters.create(s.id, first, last, gender); loadSlots(); done() }
            catch (e: Exception) { message.value = e.toUserMessage() }
            creating.value = false
        }
    }
    fun setAnimations(v: Boolean) { sl.settings.animations = v; animations.value = v }

    fun play(ctx: Context) {
        fun msg(t: String) { message.value = t }
        val server = selectedServer.value ?: return msg("Сервер не выбран")
        val ch = (slots.value as? Ui.Ok)?.v?.getOrNull(selectedSlot.value ?: -1) ?: return msg("Персонаж не выбран")
        val l = sl.launcher
        if (!l.isClientInstalled(ctx)) return msg(notInstalled(ctx))
        if (!l.verifyFiles(ctx)) return msg("Игровые файлы повреждены или отсутствуют")
        if (launching.value) return
        launching.value = true
        viewModelScope.launch {
            message.value = try {
                val t = sl.tickets.ticket(ch.id.toLong()) // одноразовый билет на 60 секунд
                val payload = JSONObject().put("nickname", t.nickname).put("host", server.host ?: "")
                    .put("port", server.port).put("skin_id", t.skin_id).put("ticket", t.ticket).toString()
                when (val r = l.launch(ctx, server, ch, payload)) {
                    is LaunchResult.Failure -> r.reason
                    LaunchResult.Success -> "Код входа скопирован: вставьте его в окне входа на сервере"
                }
            } catch (e: Exception) { e.toUserMessage() }
            launching.value = false
        }
    }
    private fun notInstalled(ctx: Context): String {
        if (AppConfig.CLIENT_PACKAGE.isBlank()) return "Клиент не настроен: укажите CLIENT_PACKAGE в AppConfig"
        val url = AppConfig.CLIENT_DOWNLOAD_URL
        if (url.isNotBlank()) runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return "Игровой клиент не установлен" + if (url.isNotBlank()) ". Открываю страницу загрузки." else ""
    }
    fun checkUpdates() = viewModelScope.launch {
        message.value = try {
            val v = sl.updates.latestVersion()
            if (v == "1.0.0") "У вас последняя версия ($v)" else "Доступна версия $v"
        } catch (e: Exception) { "Не удалось проверить обновления" }
    }
    fun clearMessage() { message.value = null }
}
