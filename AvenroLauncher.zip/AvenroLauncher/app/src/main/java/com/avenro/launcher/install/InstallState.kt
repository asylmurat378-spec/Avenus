package com.avenro.launcher.install

import android.content.Intent
import com.google.gson.annotations.SerializedName

// ---------- Манифест игры (JSON на вашем хостинге) ----------
data class ApkEntry(val url: String = "", val sha256: String = "", val size: Long = 0)

data class FileEntry(
    val url: String = "",
    val sha256: String = "",
    val size: Long = 0,
    /** "obb" -> Android/obb/<package>/, "data" -> Android/data/<package>/files/, "launcher" -> папка лаунчера */
    val dest: String = "obb",
    /** Путь файла внутри dest. Для unzip=true не используется (путь берётся из архива). */
    val path: String = "",
    val unzip: Boolean = false,
    /** Размер после распаковки (для проверки свободного места и прогресса) */
    @SerializedName("unzipped_size") val unzippedSize: Long = 0
)

data class GameManifest(
    val version: String = "",
    @SerializedName("package") val pkg: String = "",
    @SerializedName("version_code") val versionCode: Long = 0,
    val apk: ApkEntry = ApkEntry(),
    val files: List<FileEntry> = emptyList()
)

class Plan(val manifest: GameManifest, val installApk: Boolean, val files: List<FileEntry>) {
    val needsWork: Boolean get() = installApk || files.isNotEmpty()
    val bytes: Long get() = (if (installApk) manifest.apk.size else 0L) + files.sumOf { it.size }
}

class InstallException(msg: String) : Exception(msg)

// ---------- Состояние для UI ----------
enum class Stage(val title: String) {
    PREPARE("Подготовка"), DOWNLOAD("Загрузка"), VERIFY("Проверка целостности"),
    UNPACK("Распаковка"), INSTALL("Установка")
}

sealed interface InstallState {
    object Idle : InstallState
    data class Working(val stage: Stage, val label: String, val done: Long, val total: Long, val speed: Long) : InstallState
    /** Системное окно подтверждения установки: его нужно показать пользователю */
    data class NeedsConfirm(val intent: Intent) : InstallState
    object Done : InstallState
    data class Failed(val message: String) : InstallState
}

fun fmtBytes(b: Long): String = when {
    b >= (1L shl 30) -> "%.2f ГБ".format(b / 1073741824.0)
    b >= (1L shl 20) -> "%.1f МБ".format(b / 1048576.0)
    b >= (1L shl 10) -> "%.0f КБ".format(b / 1024.0)
    else -> "$b Б"
}
