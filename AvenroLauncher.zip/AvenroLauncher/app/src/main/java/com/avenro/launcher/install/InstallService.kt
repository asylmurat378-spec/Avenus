package com.avenro.launcher.install

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Foreground-сервис: загрузка продолжается, даже если игрок свернул лаунчер. */
class InstallService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Загрузка игры", NotificationManager.IMPORTANCE_LOW))
        }
        val first = build("Подготовка…", 0, 0)
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(ID, first)
        scope.launch {
            GameInstaller.state.collect { s ->
                if (s is InstallState.Working) nm.notify(ID, build("${s.stage.title}: ${s.label}", s.done, s.total))
            }
        }
        GameInstaller.launchJob(scope, applicationContext) { stopSelf() }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private fun build(text: String, done: Long, total: Long): Notification =
        NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("AVENRO ROLEPLAY")
            .setContentText(text)
            .setOnlyAlertOnce(true).setOngoing(true)
            .apply {
                if (total > 0) setProgress(100, (done * 100 / total).toInt().coerceIn(0, 100), false)
                else setProgress(0, 0, true)
            }.build()

    companion object { const val CH = "install"; const val ID = 77 }
}
